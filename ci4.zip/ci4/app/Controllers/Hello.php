<?php

namespace App\Controllers;

class Hello extends BaseController
{
    public function index()
    {
        echo ('Hello World! Life is Happiness');
    }
    public function show(){
        echo "I Make The World Better Place";
    }
}
