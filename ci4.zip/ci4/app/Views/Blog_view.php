<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <title><?= $title;?></title>
</head>
<boby>
    <h1><?= $content; ?></h1>
</body>
</html>