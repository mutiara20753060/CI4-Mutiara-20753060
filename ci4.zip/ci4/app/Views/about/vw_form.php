<!DOCTYPE html>
<html>
<head>
    <title>Biodata Mahasiswa</title>
</head>
<body>
    <form action="contact.php" method="POST">
        <fieldset>
        <legend>Biodata Mahasiswa</legend>
        <p>
            <label>NPM:</label>
            <input type="text" name="NPM" placeholder="Masukan NPM..." />
        </p>
        <p>
            <label>Nama:</label>
            <input type="text" name="Nama" placeholder="Masukan Nama..." />
        </p>
        <p>
            <label>Email:</label>
            <input type="email" name="email" placeholder="Your email..." />
        </p>
        <p>
            <label>Jenis kelamin:</label>
            <label><input type="radio" name="jenis_kelamin" value="laki-laki" /> Laki-laki</label>
            <label><input type="radio" name="jenis_kelamin" value="perempuan" /> Perempuan</label>
        </p>
        <p>
            <label>Agama:</label>
            <select name="agama">
            <option value="islam">Katolik</option>
                <option value="islam">Islam</option>
                <option value="kristen">Kristen</option>
                <option value="hindu">Hindu</option>
                <option value="budha">Budha</option>
            </select>
        </p>
        <p>
            <label>Alamat:</label>
            <textarea name="Alamat"></textarea>
        </p>
        <p>
            <input type="submit" name="submit" value="Daftar" />
        </p>
        </fieldset>
    </form>
</body>
</html>